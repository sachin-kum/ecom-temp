import React from "react";
import Header from "../components/layout/Header";
import Hero from "../components/route/hero/Hero";

function HomePage() {
  return (
    <>
      <Header activeHeading={1} />
      <Hero />
    </>
  );
}

export default HomePage;
