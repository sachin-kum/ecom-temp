import React from "react";
import Singup from "../components/signup/Signup";

const SignupPage = () => {
  return (
    <div>
      <Singup />
    </div>
  );
};

export default SignupPage;
