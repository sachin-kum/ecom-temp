export const server = "http://localhost:5000/api/v1";
