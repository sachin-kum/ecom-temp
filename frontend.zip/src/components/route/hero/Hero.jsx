import React from "react";

const Hero = () => {
  return (
    <>
      <div
        className="relative  w-full"
        style={{
          backgroundImage:
            "url(https://themes.rslahmed.dev/rafcart/assets/images/banner-2.jpg)",
        }}
      >
        <div className="w-[60%] mx-auto">
          <div className="max-w-[800px] ">
            <h1 className="text-[55px] leading-[1.2] text-[#3d3a3a] font-[600] capitalize ">
              Best Collection for
              <br /> home Decaration
            </h1>
            <p>
              Lorem ipsum dolor sit amet consectetur, adipisicing elit. Beatae,
              assumenda? Quisquam itaque exercitationem labore vel, dolore
              quidem asperiores, laudantium temporibus soluta optio consequatur
              aliquam deserunt officia. Dolorum saepe nulla provident.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Hero;
