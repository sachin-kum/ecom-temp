import React from "react";

const Cart = () => {
  return (
    <div>
      <h1 className="text-4xl fixed right-0 h-screen z-10 bg-red-400 ">
        This is my card for show cart details
      </h1>
    </div>
  );
};

export default Cart;
