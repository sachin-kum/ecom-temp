import React from "react";

const Dropwon = ({ categoriesData, setDropDown }) => {
  return (
    <>
      <div className=" bg-white rounded-b-md border-t-2 shadow-sm w-[270px]  absolute z-30">
        {categoriesData &&
          categoriesData.map((res) => {
            return (
              <div
                className="flex mt-2 place-items-center cursor-pointer"
                onClick={() => setDropDown(false)}
              >
                <img
                  src={res?.image_Url}
                  className="w-[40px] h-[40px] mr-[10px]"
                />
                <p>{res?.title}</p>
              </div>
            );
          })}
      </div>
    </>
  );
};

export default Dropwon;
